<?php defined('AUTOMAD') or die('Direct access not permitted!'); ?>
<@ snippets/header.php @>
	<div class="uk-flex">
		<@ snippets/sidebar.php @>
		<div class="uk-width-large-3-4">
			<div class="content uk-block sidebar-block">
				<@ snippets/content.php @>
				<@ snippets/related_simple.php @>
			</div>
		</div>
	</div>
<@ snippets/footer.php @>