<?php defined('AUTOMAD') or die('Direct access not permitted!'); ?>
<@ snippets/header.php @>
	<div class="content uk-block">
		<@ snippets/content.php @>
	</div>
	<div class="content uk-block">
		<@ snippets/related_posts.php @>
	</div>
<@ snippets/footer.php @>