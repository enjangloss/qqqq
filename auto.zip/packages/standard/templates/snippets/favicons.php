<?php defined('AUTOMAD') or die('Direct access not permitted!'); ?>	
	<@ with @{ imageFavicon } @><link href="@{ :file }" rel="shortcut icon" type="image/x-icon" /><@ end @>
	<@ with @{ imageAppleTouchIcon } @><link href="@{ :file }" rel="apple-touch-icon" /><@ end @>