<?php defined('AUTOMAD') or die('Direct access not permitted!'); ?>
<h3 class="uk-margin-top">
	<svg xmlns="http://www.w3.org/2000/svg" width="1.2em" height="0.92em" viewBox="0 0 35 30">
		<path d="M21,0H9v12l14,14l12-12L21,0z M12,10.757V3h7.758l11,11L23,21.758L12,10.757z"/>
		<polygon points="14.879,20.879 14,21.758 3,10.757 3,3 7,3 7,0 0,0 0,12 14,26 17,23 	"/>
	</svg>&nbsp;
	@{ labelRelated | def ('Related Pages') }
</h3>