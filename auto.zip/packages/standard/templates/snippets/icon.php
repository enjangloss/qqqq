<?php defined('AUTOMAD') or die('Direct access not permitted!'); ?>
<@~ if @{ pageIconSvg } ~@>
	<div class="panel-icon">@{ pageIconSvg }</div>
<@~ end @>