<?php defined('AUTOMAD') or die('Direct access not permitted!'); ?>
<div id="sidebar" class="uk-width-1-4 uk-visible-large">
	<div class="uk-block sidebar-inner">
		<@ tree.php @>	
	</div>
</div>