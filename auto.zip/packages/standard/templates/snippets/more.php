<?php defined('AUTOMAD') or die('Direct access not permitted!'); ?>
<a href="@{ url }" class="nav-link panel-more">
	<svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 30 30">
		<polygon points="5,0 5,5 21.001,5 21,5 0,25.986 3.993,30 25,9 25,25 30,25 30,0 "/>
	</svg>
</a>