<@ if not @{ someVariable | def (false) } @>
	False
<@ end @>