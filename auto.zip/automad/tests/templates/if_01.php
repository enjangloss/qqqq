<@ if @{ x | -@{ x | -5 } } = 5 @>
	True
<@ else @>
	False
<@ end @>