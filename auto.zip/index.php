<?php

define('AUTOMAD', true);
define('AM_BASE_DIR', __DIR__);
require AM_BASE_DIR . '/automad/init.php';

?>
